import hashlib
import json
import os
from pathlib import Path
from threading import Lock
from uuid import UUID

from dotenv import dotenv_values

from app.services.embeddings.bge import (
    MODEL_NAME,
    QUERY_INSTRUCTION,
    BgeEmbedding,
)
from app.services.rag.answering import AnsweringService
from app.services.retrieval.milvus_store import MilvusStore
from app.services.retrieval.reranker import BgeReranker

PROJECT_ROOT = Path(__file__).resolve().parents[4]

_runtime = None
_runtime_lock = Lock()


class RagBusyError(Exception):
    pass


def load_snapshot(document_id: UUID) -> tuple[dict, str]:
    registry_path = PROJECT_ROOT / "rag_sources.json"

    if not registry_path.is_file():
        raise ValueError("服务器尚未配置 rag_sources.json。")

    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    relative_path = registry.get(str(document_id))

    if not relative_path:
        raise ValueError("这份文档尚未登记可用的向量快照。")

    manifest_path = Path(relative_path)
    if not manifest_path.is_absolute():
        manifest_path = PROJECT_ROOT / manifest_path

    raw = manifest_path.read_bytes()
    manifest = json.loads(raw.decode("utf-8"))

    if (
        manifest.get("stage") != "embedded"
        or manifest.get("model_name") != MODEL_NAME
        or manifest.get("dimension") != 1024
        or manifest.get("query_instruction") != QUERY_INSTRUCTION
        or manifest.get("normalized") is not True
        or manifest.get("document_id") != str(document_id)
    ):
        raise ValueError("登记的向量快照与当前文档或模型不兼容。")

    chunks = manifest.get("chunks", [])
    if not chunks or len(chunks) != manifest.get("chunk_count"):
        raise ValueError("向量快照的文本块数量异常。")

    snapshot_id = hashlib.sha256(raw).hexdigest()
    return manifest, snapshot_id


class RagRuntime:
    def __init__(self) -> None:
        # 系统环境变量优先于 .env。
        config = {
            **dotenv_values(PROJECT_ROOT / ".env"),
            **os.environ,
        }

        self.answering = AnsweringService(
            base_url=config.get("RAG_LLM_BASE_URL") or "https://api.deepseek.com",
            api_key=config.get("RAG_LLM_API_KEY") or "",
            model=config.get("RAG_LLM_MODEL") or "deepseek-flash",
        )

        try:
            self.embedder = BgeEmbedding(
                cache_dir=PROJECT_ROOT / "storage" / "models",
                device="auto",
            )
            self.reranker = BgeReranker(
                cache_dir=PROJECT_ROOT / "storage" / "models",
                device="cpu",
            )
        except Exception:
            self.answering.close()
            raise

    def close(self) -> None:
        self.answering.close()

    def ask(
        self,
        manifest: dict,
        snapshot_id: str,
        question: str,
        candidate_k: int,
        top_k: int,
        min_score: float,
    ) -> dict:
        kb_id = manifest["knowledge_base_id"]
        doc_id = manifest["document_id"]

        # Milvus 客户端按请求创建和关闭。
        # 模型与 HTTP 客户端则跨请求复用。
        store = MilvusStore()

        try:
            store.ensure_collection()

            count = store.count_snapshot(kb_id, doc_id, snapshot_id)
            if count != manifest["chunk_count"]:
                raise RuntimeError("Milvus 中的快照记录不完整，请重新入库。")

            vector = self.embedder.encode_query(question)

            candidates = store.search(
                vector=vector.tolist(),
                knowledge_base_id=kb_id,
                document_id=doc_id,
                snapshot_id=snapshot_id,
                limit=candidate_k,
            )

            ranked = self.reranker.rank(
                question=question,
                hits=candidates,
                batch_size=2,
            )

            accepted = [hit for hit in ranked if hit["rerank_score"] >= min_score]
            selected = accepted[:top_k]

            common = {
                "knowledge_base_id": kb_id,
                "document_id": doc_id,
                "snapshot_id": snapshot_id,
                "retrieved_count": len(candidates),
                "accepted_count": len(selected),
            }

            if not selected:
                return {
                    **common,
                    "status": "insufficient_evidence",
                    "answer": (
                        "当前检索结果未达到相关性阈值。"
                        "可以换一种问法；这不代表整份文档一定没有答案。"
                    ),
                    "citation_ids": [],
                    "citation_check": "not_applicable",
                    "sources": [],
                }

            result = self.answering.answer(question, selected)

            return {
                **common,
                "status": "answered",
                "answer": result["answer"],
                "citation_ids": result["citation_ids"],
                "citation_check": result["citation_check"],
                "sources": result["sources"],
            }

        finally:
            store.close()


def ask_with_runtime(
    manifest: dict,
    snapshot_id: str,
    question: str,
    candidate_k: int,
    top_k: int,
    min_score: float,
) -> dict:
    global _runtime

    # 本机阶段一次只执行一个 RAG 请求。
    # 不让多个请求同时加载模型或争抢显存。
    if not _runtime_lock.acquire(blocking=False):
        raise RagBusyError("已有问答正在处理，请稍后重试。")

    try:
        if _runtime is None:
            _runtime = RagRuntime()

        return _runtime.ask(
            manifest=manifest,
            snapshot_id=snapshot_id,
            question=question,
            candidate_k=candidate_k,
            top_k=top_k,
            min_score=min_score,
        )
    finally:
        _runtime_lock.release()


def close_runtime() -> None:
    global _runtime

    with _runtime_lock:
        if _runtime is not None:
            _runtime.close()
            _runtime = None
